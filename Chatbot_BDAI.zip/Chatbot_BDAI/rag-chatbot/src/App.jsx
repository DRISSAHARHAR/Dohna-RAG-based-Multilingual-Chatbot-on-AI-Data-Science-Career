import React, { useState, useRef, useEffect, useCallback } from "react";
import "./App.css";
import logoImage from './images/hhrr.png';

export default function App() {
  // Initial bot welcome message
  const initialMessage = {
    sender: "bot",
    content: [
      { type: "text", text: "Hi, I'm DoHna." },
      { type: "text", text: "How can I help you today?" }
    ]
  };

  const [messages, setMessages] = useState([initialMessage]);
  const [showSidebar, setShowSidebar] = useState(window.innerWidth > 640);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [chatHistory, setChatHistory] = useState([]);
  const [showEmojis, setShowEmojis] = useState(false);
  const [hasActiveChatHistory, setHasActiveChatHistory] = useState(false);
  
  const inputRef = useRef(null);
  const textareaRef = useRef(null);
  const chatContainerRef = useRef(null);
  const emojiPickerRef = useRef(null);

  // Handle window resize for sidebar visibility
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth > 640) {
        setShowSidebar(true);
      } else if (window.innerWidth <= 640 && showSidebar) {
        setShowSidebar(false);
      }
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [showSidebar]);

  // Handle clicking outside of emoji picker to close it
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        showEmojis &&
        emojiPickerRef.current && 
        !emojiPickerRef.current.contains(event.target) &&
        event.target.className !== "input-button emoji-button" &&
        !event.target.closest(".emoji-button")
      ) {
        setShowEmojis(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [showEmojis]);

  // Scroll to bottom when messages change
  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [messages]);

  // Focus input on component mount
  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const toggleSidebar = () => {
    setShowSidebar(!showSidebar);
  };

  // Send message to API and handle response
  const sendMessage = useCallback(async () => {
    if (!input.trim()) return;
    
    const userMessage = { 
      sender: "user", 
      content: [{ type: "text", text: input.trim() }] 
    };
    
    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setLoading(true);
    
    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
    }

    try {
      // API call to backend
      const res = await fetch("http://localhost:8000/ask", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ question: userMessage.content[0].text }),
      });
      
      if (!res.ok) {
        throw new Error(`Server responded with status: ${res.status}`);
      }
      
      const data = await res.json();
      
      // Process the bot's response
      const botMessage = { 
        sender: "bot", 
        content: [{ type: "text", text: data.answer || "I didn't get a proper response. Could you try again?" }] 
      };
      
      setMessages((prev) => [...prev, botMessage]);
      
      // Update chat history status
      if (!hasActiveChatHistory) {
        setHasActiveChatHistory(true);
      }
    } catch (err) {
      console.error("Error sending message:", err);
      
      setMessages((prev) => [
        ...prev,
        { 
          sender: "bot", 
          content: [{ 
            type: "text", 
            text: "❌ Sorry, I couldn't process your request. Please try again later." 
          }] 
        },
      ]);
    } finally {
      setLoading(false);
    }
  }, [input, hasActiveChatHistory]);

  // Start a new chat conversation
  const startNewChat = () => {
    // Save current conversation to history if it contains user messages
    if (messages.some(msg => msg.sender === "user")) {
      const firstUserMsg = messages.find(msg => msg.sender === "user");
      const chatTitle = firstUserMsg?.content[0]?.text.slice(0, 20) + "...";
      
      const newHistoryItem = {
        id: Date.now(), // Add unique ID
        title: new Date().toLocaleDateString(),
        items: [chatTitle]
      };
      
      setChatHistory(prev => [newHistoryItem, ...prev]);
    }
    
    // Reset the chat to initial state
    setMessages([initialMessage]);
    setInput("");
    
    // Focus on input after starting new chat
    setTimeout(() => {
      inputRef.current?.focus();
    }, 0);
    
    // Close sidebar on mobile after starting new chat
    if (window.innerWidth <= 640) {
      setShowSidebar(false);
    }
  };

  // Handle keyboard shortcuts
  const handleKeyDown = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    } else if (e.key === "Escape") {
      setShowEmojis(false);
    }
  };

  // Adjust textarea height based on content
  const adjustTextareaHeight = () => {
    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
      const newHeight = Math.min(textareaRef.current.scrollHeight, 200);
      textareaRef.current.style.height = `${newHeight}px`;
    }
  };

  // Common emojis for quick insertion
  const emojis = ["😊", "👍", "👋", "🙏", "😂", "❤️", "🔥", "✅", "⭐", "🎉", "🤔", "👀", "💡", "🚀", "💪", "🌟", "🙌", "👏", "💯", "🎯", "👌"];

  // Insert emoji into text input
  const insertEmoji = (emoji) => {
    setInput(prev => prev + emoji);
    setShowEmojis(false);
    
    // Focus and adjust height after inserting emoji
    setTimeout(() => {
      textareaRef.current?.focus();
      adjustTextareaHeight();
    }, 0);
  };

  return (
    <div className="app-container">
      {/* Toggle Sidebar Button - Only shown when sidebar is hidden on mobile */}
      {!showSidebar && (
        <button 
          className="toggle-sidebar visible" 
          onClick={toggleSidebar}
          aria-label="Open sidebar"
        >
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <line x1="3" y1="12" x2="21" y2="12"></line>
            <line x1="3" y1="6" x2="21" y2="6"></line>
            <line x1="3" y1="18" x2="21" y2="18"></line>
          </svg>
        </button>
      )}
      
      {/* Left Sidebar */}
      <aside className={`sidebar ${showSidebar ? 'show' : ''}`}>
        {/* Logo */}
        <div className="logo-container">
          <img src={logoImage} alt="DoHna Logo" className="logo-image" />
          <span className="logo-text">DoHna</span>
          <button 
            className="close-button" 
            onClick={toggleSidebar}
            aria-label="Close sidebar"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <line x1="18" y1="6" x2="6" y2="18"></line>
              <line x1="6" y1="6" x2="18" y2="18"></line>
            </svg>
          </button>
        </div>
        
        {/* New Chat Button */}
        <div className="new-chat-container">
          <button 
            className="new-chat-button" 
            onClick={startNewChat}
            aria-label="Start new chat"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M12 5v14M5 12h14"></path>
            </svg>
            <span>New chat</span>
          </button>
        </div>
        
        {/* Chat History - only shown when there are actual history items */}
        {hasActiveChatHistory && chatHistory.length > 0 && (
          <nav className={`history-container ${chatHistory.length > 0 ? 'has-history' : ''}`}>
            {chatHistory.map((section) => (
              <div key={section.id} className="history-section">
                <h3 className="history-title">{section.title}</h3>
                <ul className="history-list">
                  {section.items.map((item, i) => (
                    <li key={`${section.id}-${i}`} className="history-item">
                      <button 
                        className="history-link" 
                        onClick={() => {
                          // Here you would load the selected chat
                          console.log("Load chat:", item);
                          // For now just close sidebar on mobile
                          if (window.innerWidth <= 640) {
                            setShowSidebar(false);
                          }
                        }}
                      >
                        {item}
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </nav>
        )}
        
        {/* Get App Button */}
        <div className="get-app-container">
          <button 
            className="get-app-button"
            aria-label="Get mobile app"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <rect x="5" y="2" width="14" height="20" rx="2" ry="2"></rect>
              <line x1="12" y1="18" x2="12" y2="18"></line>
            </svg>
            <span>Get App</span>
            <span className="new-badge">NEW</span>
          </button>
        </div>
        
        {/* User Profile */}
        <div className="profile-container">
          <div className="profile">
            <div className="avatar" aria-label="User avatar">
              D
            </div>
            <span className="profile-text">ENSATé</span>
          </div>
        </div>
      </aside>
      
      {/* Main Chat Area */}
      <main className="main-content">
        {/* Chat Messages */}
        <div 
          ref={chatContainerRef} 
          className="chat-container"
          aria-live="polite"
        >
          <div className="messages-wrapper">
            {messages.map((message, idx) => (
              <div 
                key={idx} 
                className={`message-row ${message.sender === 'user' ? 'user-message-row' : 'bot-message-row'}`}
              >
                {message.sender === 'bot' && (
                  <div className="bot-avatar" aria-hidden="true">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M12 2c-2.4 0-4 1.6-4 4 0 1.1.1 2.3-.5 3.6-1 2.2-3.3 2.8-3.5 4.9-.3 1.2.8 2.5 2 2.5h12c1.2 0 2.3-1.3 2-2.5-.2-2.1-2.5-2.7-3.5-4.9-.6-1.3-.5-2.5-.5-3.6 0-2.4-1.6-4-4-4z"></path>
                      <path d="M12 16v3"></path>
                      <path d="M8 22h8"></path>
                    </svg>
                  </div>
                )}
                
                <div 
                  className={`message-container ${message.sender === 'bot' ? 'bot-message' : 'user-message'}`}
                  aria-label={`${message.sender === 'bot' ? 'Assistant' : 'You'} message`}
                >
                  {message.content.map((item, i) => (
                    <div 
                      key={i} 
                      className={`message-bubble ${
                        message.sender === 'user' 
                          ? 'user-bubble' 
                          : 'bot-bubble'
                      }`}
                    >
                      {item.text}
                    </div>
                  ))}
                </div>
              </div>
            ))}
            
            {loading && (
              <div className="message-row bot-message-row">
                <div className="bot-avatar" aria-hidden="true">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M12 2c-2.4 0-4 1.6-4 4 0 1.1.1 2.3-.5 3.6-1 2.2-3.3 2.8-3.5 4.9-.3 1.2.8 2.5 2 2.5h12c1.2 0 2.3-1.3 2-2.5-.2-2.1-2.5-2.7-3.5-4.9-.6-1.3-.5-2.5-.5-3.6 0-2.4-1.6-4-4-4z"></path>
                    <path d="M12 16v3"></path>
                    <path d="M8 22h8"></path>
                  </svg>
                </div>
                <div className="message-container bot-message">
                  <div className="message-bubble bot-bubble">
                    <div className="dot-typing" aria-label="Loading response">
                      <div className="dot dot1"></div>
                      <div className="dot dot2"></div>
                      <div className="dot dot3"></div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
        
        {/* Input Area */}
        <div className="input-area">
          <div className="input-wrapper">
            <div className="textarea-container">
              <textarea
                ref={textareaRef}
                className="message-input"
                placeholder="Message DoHna..."
                rows="1"
                value={input}
                onChange={(e) => {
                  setInput(e.target.value);
                  adjustTextareaHeight();
                }}
                onKeyDown={handleKeyDown}
                aria-label="Type your message"
              ></textarea>
              
              <div className="input-buttons right-buttons">
                <button 
                  className="input-button info-button"
                  aria-label="Information"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="12" cy="12" r="10"></circle>
                    <line x1="12" y1="16" x2="12" y2="12"></line>
                    <line x1="12" y1="8" x2="12.01" y2="8"></line>
                  </svg>
                </button>
                
                <button
                  onClick={sendMessage}
                  disabled={!input.trim() || loading}
                  className={`input-button send-button ${
                    !input.trim() || loading 
                      ? 'disabled' 
                      : ''
                  }`}
                  aria-label="Send message"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="m3 3 3 9-3 9 19-9Z"></path>
                    <path d="M6 12h16"></path>
                  </svg>
                </button>
              </div>
              
              <div className="input-buttons left-buttons">
                <div className="emoji-container">
                  <button 
                    className="input-button emoji-button"
                    onClick={() => setShowEmojis(!showEmojis)}
                    aria-label="Open emoji picker"
                    aria-expanded={showEmojis}
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <circle cx="12" cy="12" r="10"></circle>
                      <path d="M8 14s1.5 2 4 2 4-2 4-2"></path>
                      <line x1="9" y1="9" x2="9.01" y2="9"></line>
                      <line x1="15" y1="9" x2="15.01" y2="9"></line>
                    </svg>
                  </button>
                  
                  {showEmojis && (
                    <div 
                      className="emoji-picker" 
                      ref={emojiPickerRef}
                      role="dialog"
                      aria-label="Emoji picker"
                    >
                      {emojis.map((emoji, index) => (
                        <button 
                          key={index} 
                          className="emoji"
                          onClick={() => insertEmoji(emoji)}
                          aria-label={`Insert emoji ${emoji}`}
                        >
                          {emoji}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
            
            <div className="disclaimer">
              AI-generated content may contain inaccuracies.
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
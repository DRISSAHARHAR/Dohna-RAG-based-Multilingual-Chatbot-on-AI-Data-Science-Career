// App.jsx
import React, { useState, useRef, useEffect } from "react";
import { motion } from "framer-motion";

export default function App() {
  const [messages, setMessages] = useState([
    { sender: "bot", text: "👋 Bonjour ! Je suis votre assistant personnel. Comment puis-je vous aider aujourd'hui ?" },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const chatRef = useRef(null);
  const inputRef = useRef(null);
  const [showSidebar, setShowSidebar] = useState(true);

  const sendMessage = async () => {
    if (!input.trim()) return;
    const userMessage = { sender: "user", text: input };
    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setLoading(true);

    try {
      const res = await fetch("http://localhost:8000/ask", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ question: input }),
      });
      const data = await res.json();
      const botMessage = { sender: "bot", text: data.answer };
      setMessages((prev) => [...prev, botMessage]);
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        { sender: "bot", text: "❌ Désolé, je n'ai pas pu traiter votre demande. Veuillez réessayer plus tard." },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const startNewChat = () => {
    setMessages([
      { sender: "bot", text: "👋 Bonjour ! Je suis votre assistant personnel. Comment puis-je vous aider aujourd'hui ?" },
    ]);
    setInput("");
  };

  useEffect(() => {
    chatRef.current?.scrollTo({ top: chatRef.current.scrollHeight, behavior: "smooth" });
  }, [messages]);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const handleKeyDown = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  return (
    <div className="flex h-screen bg-slate-100">
      {/* Sidebar */}
      {showSidebar && (
        <div className="w-64 bg-slate-800 text-white flex flex-col">
          {/* Logo & App Name */}
          <div className="p-4 flex items-center justify-center border-b border-slate-700">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-full bg-gradient-to-r from-purple-600 to-blue-500 flex items-center justify-center text-xl">
                🤖
              </div>
              <h1 className="text-lg font-bold">ChatBot AI</h1>
            </div>
          </div>
          
          {/* Sidebar Menu */}
          <div className="flex-1 overflow-y-auto p-3 space-y-3">
            <button 
              onClick={startNewChat}
              className="w-full flex items-center gap-2 p-3 hover:bg-slate-700 rounded-lg transition-colors text-left"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
              </svg>
              Nouveau Chat
            </button>
            
            <button 
              className="w-full flex items-center gap-2 p-3 hover:bg-slate-700 rounded-lg transition-colors text-left"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
              </svg>
              Paramètres
            </button>
          </div>
          
          {/* User Info */}
          <div className="p-4 border-t border-slate-700">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-slate-600 flex items-center justify-center">
                👤
              </div>
              <div>
                <p className="text-sm font-medium">Utilisateur</p>
                <p className="text-xs text-slate-400">Connecté</p>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* Main Content */}
      <div className="flex-1 flex flex-col relative">
        {/* Toggle Sidebar Button */}
        <button 
          onClick={() => setShowSidebar(!showSidebar)}
          className="absolute top-4 left-4 z-10 bg-slate-200 p-2 rounded-full hover:bg-slate-300"
        >
          {showSidebar ? (
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 19l-7-7 7-7m8 14l-7-7 7-7" />
            </svg>
          ) : (
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 5l7 7-7 7M5 5l7 7-7 7" />
            </svg>
          )}
        </button>
        
        {/* Chat Container */}
        <main ref={chatRef} className="flex-1 overflow-y-auto bg-white">
          <div className="max-w-4xl mx-auto px-6 py-6">
            {messages.map((msg, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
                className={`flex mb-6 ${msg.sender === "user" ? "justify-end" : "justify-start"}`}
              >
                <div className={`flex ${msg.sender === "user" ? "flex-row-reverse" : "flex-row"} max-w-[80%] gap-3`}>
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${
                    msg.sender === "user" 
                      ? "bg-blue-600" 
                      : "bg-gradient-to-r from-purple-600 to-blue-500"
                  }`}>
                    {msg.sender === "user" ? "👤" : "🤖"}
                  </div>
                  
                  <div className={`py-3 px-4 rounded-2xl ${
                    msg.sender === "user"
                      ? "bg-blue-600 text-white"
                      : "bg-slate-100 text-slate-800 border border-slate-200"
                  }`}>
                    <div className="text-sm whitespace-pre-wrap">
                      {msg.text}
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
            
            {loading && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex mb-6"
              >
                <div className="flex flex-row max-w-[80%] gap-3">
                  <div className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 bg-gradient-to-r from-purple-600 to-blue-500">
                    🤖
                  </div>
                  
                  <div className="py-3 px-4 rounded-2xl bg-slate-100 text-slate-800 border border-slate-200">
                    <div className="flex gap-2 p-2">
                      <div className="w-2 h-2 bg-blue-600 rounded-full animate-bounce"></div>
                      <div className="w-2 h-2 bg-blue-600 rounded-full animate-bounce" style={{ animationDelay: "0.2s" }}></div>
                      <div className="w-2 h-2 bg-blue-600 rounded-full animate-bounce" style={{ animationDelay: "0.4s" }}></div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </div>
        </main>

        {/* Input Area */}
        <div className="bg-white border-t border-slate-200 py-4 px-6">
          <div className="max-w-4xl mx-auto relative">
            <textarea
              ref={inputRef}
              className="w-full border border-slate-300 rounded-xl px-4 py-4 pr-16 resize-none focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent min-h-[100px] text-slate-800 placeholder-slate-400"
              placeholder="Posez votre question ici..."
              rows="3"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
            ></textarea>
            
            <button
              onClick={sendMessage}
              disabled={loading || !input.trim()}
              className={`absolute right-3 bottom-3 p-3 rounded-lg ${
                loading || !input.trim() 
                  ? "bg-slate-300 cursor-not-allowed text-slate-500" 
                  : "bg-blue-600 hover:bg-blue-700 text-white"
              }`}
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
              </svg>
            </button>
          </div>
          
          <p className="text-xs text-slate-500 mt-2 text-center">
            Je suis un assistant IA. Mes réponses peuvent parfois contenir des erreurs.
          </p>
        </div>
      </div>
    </div>
  );
}
# app.py
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.vectorstores import Chroma
from langchain_community.llms import HuggingFaceEndpoint
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import StrOutputParser
from operator import itemgetter

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # mets ici ton frontend si besoin
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-mpnet-base-v2")
vectorstore = Chroma(
    persist_directory="C:\\Users\\DELL\\Downloads\\chroma_db_bd",  
    embedding_function=embeddings
)
retriever = vectorstore.as_retriever(search_kwargs={"k": 5})

template = """Answer the question based on the context below. If you can't answer the question, reply \"I don't know\".\n\nContext: {context}\nQuestion: {question}"""
prompt = PromptTemplate.from_template(template)

llm = HuggingFaceEndpoint(
    repo_id="mistralai/Mixtral-8x7B-Instruct-v0.1",
    huggingfacehub_api_token="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",
    temperature=0.7,
    max_new_tokens=100,
    task="text-generation"
)

parser = StrOutputParser()

chain = (
    {
        "context": itemgetter("question") | retriever,
        "question": itemgetter("question"),
    }
    | prompt
    | llm
    | parser
)

@app.post("/ask")
async def ask_question(req: Request):
    body = await req.json()
    question = body.get("question", "")
    answer = chain.invoke({"question": question})
    return {"answer": answer}
